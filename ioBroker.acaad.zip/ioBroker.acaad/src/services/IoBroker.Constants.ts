export const Actions = {
  Sync: 'Sync',
  Trigger: 'Trigger',
  Switch: 'Switch'
};
